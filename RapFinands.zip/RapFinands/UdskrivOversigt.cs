namespace Rap_Finands {
    class UdskrivKontoOversigt {
        /*public static void Main(string[] args) {
             
        }*/
        public static void HentKonto(string kontonr) {
            
        }
    }
}
/** 
Koden er lavet til undervisningbrug på TECHCOLLEGE
Voldum Bank og nævnte personer er fiktive.
~Simon Hoxer Bønding
**/