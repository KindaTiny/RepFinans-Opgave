using System;

namespace Rap_Finands {
    class Transaktion {
        public string tekst;
        public float saldo;
        public float amount;
        public DateTime dato;
        
    }
}
/** 
Koden er lavet til undervisningbrug på TECHCOLLEGE
Voldum Bank og nævnte personer er fiktive.
~Simon Hoxer Bønding
**/